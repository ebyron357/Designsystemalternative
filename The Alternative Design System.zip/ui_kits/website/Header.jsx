function Header({ page, onNav }) {
  const links = ['Home', 'Products', 'Transparency', 'Wholesale'];
  return React.createElement('header', {
    style: { position: 'sticky', top: 0, zIndex: 10, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '20px var(--container-pad)', background: 'rgba(14,14,14,.88)', backdropFilter: 'blur(8px)', borderBottom: '1px solid var(--border-dark)' },
  },
    React.createElement('div', { style: { fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 20, color: 'var(--gold-300)', letterSpacing: '-0.01em', cursor: 'pointer' }, onClick: () => onNav('Home') }, 'ALTERNATIVE™'),
    React.createElement('nav', { style: { display: 'flex', gap: 32 } },
      links.map(l => React.createElement('span', {
        key: l, onClick: () => onNav(l),
        style: { cursor: 'pointer', fontFamily: 'var(--font-sans)', fontWeight: 700, fontSize: 12, letterSpacing: 'var(--tracking-label)', textTransform: 'uppercase', color: page === l ? 'var(--gold-300)' : 'var(--text-secondary-dark)' },
      }, l))),
    React.createElement(window.TheAlternativeDesignSystem_cd1e63.Button, { size: 'sm', variant: 'primary' }, 'Where To Buy'));
}
window.Header = Header;
