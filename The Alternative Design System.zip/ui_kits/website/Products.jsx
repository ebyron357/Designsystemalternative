function Products({ onSelect }) {
  const { Card, Tag, Button, DoseLadder } = window.TheAlternativeDesignSystem_cd1e63;
  const [tier, setTier] = React.useState('social');
  const products = [
    { tier: 'session', mg: 5, label: 'SESSION™', copy: 'Entry-level and sessionable. Casual socializing, dinner, early evening.' },
    { tier: 'social', mg: 10, label: 'SOCIAL™', copy: 'Mainstream social tier. Parties, concerts, celebrations.' },
    { tier: 'reserve', mg: 50, label: 'RESERVE™', copy: 'High-strength premium tier for experienced consumers.' },
    { tier: 'ascend', mg: 100, label: 'ASCEND™', copy: 'Highest-strength tier. Specialized high-dose use.' },
  ];
  return React.createElement('div', { style: { padding: 'var(--space-8) var(--container-pad)' } },
    React.createElement('h1', { style: { fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 44, color: 'var(--ivory)', margin: 0 } }, 'The Dose Ladder'),
    React.createElement('p', { style: { fontFamily: 'var(--font-sans)', color: 'var(--text-secondary-dark)', marginTop: 12, maxWidth: 560 } }, 'Clearly dosed. Thoughtfully designed. Choose the experience that fits the occasion.'),
    React.createElement('div', { style: { marginTop: 40, maxWidth: 480 } }, React.createElement(DoseLadder, { activeTier: tier, onSelect: setTier })),
    React.createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 20, marginTop: 48 } },
      products.map(p => React.createElement(Card, { key: p.tier, style: { display: 'flex', flexDirection: 'column', gap: 14 } },
        React.createElement(Tag, { tier: p.tier, mg: p.mg, label: p.label }),
        React.createElement('div', { style: { height: 100, borderRadius: 'var(--radius-md)', overflow: 'hidden' } }, React.createElement('image-slot', { id: `prod-${p.tier}`, shape: 'rect', placeholder: `${p.label} can` })),
        React.createElement('p', { style: { fontSize: 13, color: 'var(--text-secondary-dark)', margin: 0, lineHeight: 1.5 } }, p.copy),
        React.createElement(Button, { size: 'sm', variant: 'secondary', onClick: () => onSelect(p.tier) }, 'View Product')))));
}
window.Products = Products;
