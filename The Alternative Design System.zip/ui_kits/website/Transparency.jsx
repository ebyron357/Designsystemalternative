function Transparency() {
  const { Callout, Input, Button } = window.TheAlternativeDesignSystem_cd1e63;
  const [batch, setBatch] = React.useState('');
  return React.createElement('div', { style: { padding: 'var(--space-8) var(--container-pad)', maxWidth: 640 } },
    React.createElement('h1', { style: { fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 40, color: 'var(--ivory)', margin: 0 } }, 'Know The Dose. Know The Product.'),
    React.createElement('p', { style: { fontFamily: 'var(--font-sans)', color: 'var(--text-secondary-dark)', marginTop: 12, lineHeight: 1.6 } }, 'Every batch links to a current Certificate of Analysis. Look up your can or bottle by batch code, or scan the QR printed on the label.'),
    React.createElement('div', { style: { display: 'flex', gap: 40, marginTop: 40, alignItems: 'center' } },
      React.createElement('div', { style: { width: 140, height: 140, borderRadius: 'var(--radius-md)', border: '1px solid var(--border-dark-strong)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-muted-dark)', flexShrink: 0 } }, 'QR CODE'),
      React.createElement('div', { style: { display: 'flex', gap: 12, flex: 1 } },
        React.createElement('div', { style: { flex: 1 } }, React.createElement(Input, { label: 'Batch / Lot Code', placeholder: 'e.g. ALT-0724-A', value: batch, onChange: setBatch })),
        React.createElement(Button, { variant: 'primary', style: { alignSelf: 'flex-end' } }, 'Look Up COA'))),
    React.createElement('div', { style: { marginTop: 40 } }, React.createElement(Callout, { variant: 'info', title: 'Compliance' }, 'Statements have not been evaluated by the FDA. This product is not intended to diagnose, treat, cure, or prevent any disease.')));
}
window.Transparency = Transparency;
