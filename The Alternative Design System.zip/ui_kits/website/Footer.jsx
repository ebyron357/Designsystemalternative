function Footer() {
  return React.createElement('footer', {
    style: { padding: 'var(--space-8) var(--container-pad) var(--space-6)', borderTop: '1px solid var(--border-dark)', fontFamily: 'var(--font-sans)' },
  },
    React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 24, marginBottom: 32 } },
      React.createElement('div', { style: { fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 22, color: 'var(--gold-300)' } }, 'ALTERNATIVE™'),
      ['Products', 'Transparency', 'Wholesale', 'Press', 'FAQ'].map(l => React.createElement('span', { key: l, style: { fontSize: 13, color: 'var(--text-secondary-dark)' } }, l))),
    React.createElement('div', { style: { fontSize: 11, color: 'var(--text-muted-dark)', lineHeight: 1.7, maxWidth: 780 } },
      'For use only by adults 21 years of age or older. Keep out of reach of children. Do not drive or operate machinery after use. Do not use if pregnant or nursing. Hemp-derived THC products are federally compliant where sold; consult local law before purchase. Statements have not been evaluated by the FDA. This product is not intended to diagnose, treat, cure, or prevent any disease.'),
    React.createElement('div', { style: { fontSize: 11, color: 'var(--text-muted-dark)', marginTop: 16 } }, '© THE ALTERNATIVE™. Veteran-owned. Built in North Carolina.'));
}
window.Footer = Footer;
