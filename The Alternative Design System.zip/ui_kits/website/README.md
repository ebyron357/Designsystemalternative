# AlternativeBev.com — UI Kit

Click-through recreation of the marketing/product site structure the brand report specifies in §15 (Website and Digital Source-of-Truth Structure). No codebase or Figma was supplied for this product — screens are built from the report's written page map, brand voice, and visual-foundations rules, using this design system's own components (`Header`/`Footer` here are page-shell only, not reusable primitives — everything else is composed from `components/`).

**Screens:** Home · Products (dose ladder) · Product Detail (per tier) · Transparency/COA · Wholesale. Navigate via the header, or by clicking a product card / tier from Home or Products.

**Imagery:** every photography slot is a `<image-slot>` placeholder (drop your own hero/product/lifestyle photography in) — the report's shot list (§14) and photography direction (§7.2) specify what belongs in each: chilled product, condensation, hospitality settings, real Passion Fruit.

Open `index.html` to try it.
