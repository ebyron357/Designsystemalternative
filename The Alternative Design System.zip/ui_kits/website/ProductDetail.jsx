function ProductDetail({ tier = 'session' }) {
  const { Tag, Tabs, Callout, Button, Badge } = window.TheAlternativeDesignSystem_cd1e63;
  const [tab, setTab] = React.useState('Overview');
  const DATA = {
    session: { mg: 5, label: 'SESSION™', copy: 'The lightest visual cue in the ladder — calm, open, conversational. Entry-level and sessionable, for casual socializing, dinner, or early evening gatherings.' },
    social: { mg: 10, label: 'SOCIAL™', copy: 'Energetic but polished. Built for parties, concerts, celebrations, and nightlife alternatives.' },
    reserve: { mg: 50, label: 'RESERVE™', copy: 'Darker, richer, limited, controlled. A premium high-strength selection for experienced consumers.' },
    ascend: { mg: 100, label: 'ASCEND™', copy: 'The strongest visual warning and clearest experienced-user positioning in the system.' },
  };
  const p = DATA[tier];
  return React.createElement('div', { style: { padding: 'var(--space-8) var(--container-pad)', display: 'flex', gap: 56 } },
    React.createElement('div', { style: { flex: 1, aspectRatio: '3/4', maxHeight: 480, borderRadius: 'var(--radius-xl)', overflow: 'hidden' } },
      React.createElement('image-slot', { id: `pdp-${tier}`, shape: 'rect', placeholder: `${p.label} — front pack shot` })),
    React.createElement('div', { style: { flex: 1, maxWidth: 460 } },
      React.createElement('div', { style: { display: 'flex', gap: 8, alignItems: 'center', marginBottom: 16 } }, React.createElement(Tag, { tier, mg: p.mg, label: p.label }), React.createElement(Badge, { variant: 'neutral' }, 'Passion Fruit')),
      React.createElement('h1', { style: { fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 36, color: 'var(--ivory)', margin: 0 } }, `${p.label} — Passion Fruit`),
      React.createElement('p', { style: { fontFamily: 'var(--font-sans)', color: 'var(--text-secondary-dark)', marginTop: 14, lineHeight: 'var(--lh-relaxed)' } }, p.copy),
      React.createElement('div', { style: { display: 'flex', gap: 14, margin: '28px 0' } }, React.createElement(Button, { variant: 'primary' }, 'Find In Store'), React.createElement(Button, { variant: 'ghost' }, 'Add To Reminder List')),
      React.createElement(Tabs, { tabs: ['Overview', 'Ingredients', 'COA'], active: tab, onChange: setTab }),
      React.createElement('div', { style: { padding: '20px 0', color: 'var(--text-secondary-dark)', fontSize: 14, lineHeight: 1.6, fontFamily: 'var(--font-sans)' } },
        tab === 'Overview' && '12 fl oz / 355 mL sleek can. Chill before serving. Hemp-derived THC beverage.',
        tab === 'Ingredients' && 'Ingredient statement pending final formula approval — do not publish unverified ingredient claims.',
        tab === 'COA' && 'Certificate of Analysis available per batch via QR code on can.'),
      React.createElement(Callout, { variant: 'warning', title: 'Age Restriction' }, 'For use only by adults 21 years of age or older. Keep out of reach of children.')));
}
window.ProductDetail = ProductDetail;
