function Home({ onNav }) {
  const { Button, Badge, Tag, Card } = window.TheAlternativeDesignSystem_cd1e63;
  return React.createElement('div', {},
    React.createElement('section', { style: { position: 'relative', minHeight: 560, display: 'flex', alignItems: 'center' } },
      React.createElement('div', { style: { position: 'absolute', inset: 0, zIndex: 0 } },
        React.createElement('image-slot', { id: 'hero-passionfruit', shape: 'rect', placeholder: 'Drop hero photography — chilled can, condensation, Passion Fruit garnish' })),
      React.createElement('div', { style: { position: 'absolute', inset: 0, background: 'linear-gradient(90deg, rgba(14,14,14,.92) 0%, rgba(14,14,14,.55) 55%, rgba(14,14,14,.15) 100%)', zIndex: 1, pointerEvents: 'none' } }),
      React.createElement('div', { style: { position: 'relative', zIndex: 2, padding: '0 var(--container-pad)', maxWidth: 620 } },
        React.createElement('div', { style: { display: 'flex', gap: 8, marginBottom: 20 } },
          React.createElement(Badge, { variant: 'outline' }, 'Veteran-Owned'), React.createElement(Badge, { variant: 'outline' }, 'North Carolina Built')),
        React.createElement('h1', { style: { fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 64, lineHeight: 'var(--lh-tight)', color: 'var(--ivory)', margin: 0 } }, 'A NEW STATE OF MIND'),
        React.createElement('p', { style: { fontFamily: 'var(--font-sans)', fontSize: 18, color: 'var(--text-secondary-dark)', marginTop: 20, lineHeight: 'var(--lh-relaxed)' } }, 'Premium hemp-derived THC beverages with clearly defined dose levels — the modern alternative to alcohol.'),
        React.createElement('div', { style: { display: 'flex', gap: 14, marginTop: 32 } },
          React.createElement(Button, { variant: 'primary', size: 'lg', onClick: () => onNav('Products') }, 'Explore The Dose Ladder'),
          React.createElement(Button, { variant: 'secondary', size: 'lg', onClick: () => onNav('Transparency') }, 'View Lab Results')))),
    React.createElement('section', { style: { padding: 'var(--space-8) var(--container-pad)' } },
      React.createElement('div', { style: { fontFamily: 'var(--font-sans)', fontWeight: 700, fontSize: 12, letterSpacing: 'var(--tracking-label)', textTransform: 'uppercase', color: 'var(--text-muted-dark)', marginBottom: 20 } }, 'Choose Your Experience'),
      React.createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 20 } },
        [['session', 5, 'SESSION™'], ['social', 10, 'SOCIAL™'], ['reserve', 50, 'RESERVE™'], ['ascend', 100, 'ASCEND™']].map(([tier, mg, label]) =>
          React.createElement(Card, { key: tier, onClick: () => onNav('Products') },
            React.createElement(Tag, { tier, mg, label }),
            React.createElement('div', { style: { marginTop: 16, height: 90, borderRadius: 'var(--radius-md)', overflow: 'hidden' } },
              React.createElement('image-slot', { id: `tier-${tier}`, shape: 'rect', placeholder: `${label} can` })))))),
    React.createElement('section', { style: { padding: '0 var(--container-pad) var(--space-9)', display: 'flex', gap: 40, alignItems: 'center' } },
      React.createElement('div', { style: { flex: 1, height: 340, borderRadius: 'var(--radius-lg)', overflow: 'hidden' } },
        React.createElement('image-slot', { id: 'hospitality-lifestyle', shape: 'rect', placeholder: 'Drop hospitality/lifestyle photography — rooftop, bar cart, gathering' })),
      React.createElement('div', { style: { flex: 1 } },
        React.createElement('h2', { style: { fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 32, color: 'var(--ivory)', margin: 0 } }, 'Built for the way adults gather now.'),
        React.createElement('p', { style: { fontFamily: 'var(--font-sans)', fontSize: 16, color: 'var(--text-secondary-dark)', marginTop: 16, lineHeight: 'var(--lh-relaxed)', maxWidth: 460 } }, 'From the bar cart to the guest list, there is another option — clearly dosed, thoughtfully designed, and made for modern hospitality.'))));
}
window.Home = Home;
