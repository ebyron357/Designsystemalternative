function Wholesale() {
  const { Badge, Button, Input, Select, Checkbox, Card } = window.TheAlternativeDesignSystem_cd1e63;
  const [email, setEmail] = React.useState('');
  const [role, setRole] = React.useState('Bar / Restaurant');
  const [ok, setOk] = React.useState(false);
  return React.createElement('div', { style: { padding: 'var(--space-8) var(--container-pad)', display: 'flex', gap: 56 } },
    React.createElement('div', { style: { flex: 1.2 } },
      React.createElement('div', { style: { display: 'flex', gap: 8, marginBottom: 16 } }, React.createElement(Badge, { variant: 'outline' }, 'Wholesale')),
      React.createElement('h1', { style: { fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 40, color: 'var(--ivory)', margin: 0 } }, 'Upgrade The Bar Cart.'),
      React.createElement('p', { style: { fontFamily: 'var(--font-sans)', color: 'var(--text-secondary-dark)', marginTop: 12, maxWidth: 460, lineHeight: 1.6 } }, 'A credible menu option, dependable supply, and staff-ready education — for hospitality partners who want to offer guests another way to gather.'),
      React.createElement('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 32 } },
        [['Dose ladder & line sheet', '4 tiers, clear positioning'], ['Case pack & pricing', 'Wholesale terms on request'], ['Staff training guide', 'Compliant talking points'], ['QR-linked COAs', 'Full batch transparency']].map(([t, d]) =>
          React.createElement(Card, { key: t }, React.createElement('div', { style: { fontWeight: 700, fontSize: 14, color: 'var(--ivory)' } }, t), React.createElement('div', { style: { fontSize: 12, color: 'var(--text-secondary-dark)', marginTop: 4 } }, d))))),
    React.createElement('div', { style: { flex: 1 } },
      React.createElement(Card, { style: { display: 'flex', flexDirection: 'column', gap: 18 } },
        React.createElement('div', { style: { fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, color: 'var(--ivory)' } }, 'Request The Buyer Deck'),
        React.createElement(Input, { label: 'Work Email', placeholder: 'buyer@venue.com', value: email, onChange: setEmail }),
        React.createElement(Select, { label: 'Business Type', options: ['Bar / Restaurant', 'Boutique Hotel', 'Retail', 'Event / Catering'], value: role, onChange: setRole }),
        React.createElement(Checkbox, { label: 'I am 21+ and licensed to purchase for resale', checked: ok, onChange: setOk }),
        React.createElement(Button, { variant: 'primary' }, 'Submit Inquiry'))));
}
window.Wholesale = Wholesale;
