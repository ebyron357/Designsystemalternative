export interface DoseLadderProps {
  activeTier?: 'session' | 'social' | 'reserve' | 'ascend';
  onSelect?: (tier: string) => void;
}
export function DoseLadder(props: DoseLadderProps): JSX.Element;
