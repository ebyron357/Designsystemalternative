**Intentional addition** — not defined by a prior source, but explicitly called for in the brand report as required wholesale/retail collateral: "Dose-navigation chart designed for adult consumer education" (§13). Visualizes the SESSION → ASCEND dose ladder as a bar chart, tier-colored, log-scaled so SESSION and SOCIAL stay legible next to ASCEND.

```jsx
<DoseLadder activeTier="social" onSelect={setTier} />
```
