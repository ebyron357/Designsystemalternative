import React from 'react';
const TIERS = [
  { key: 'session', label: 'SESSION™', mg: 5 },
  { key: 'social', label: 'SOCIAL™', mg: 10 },
  { key: 'reserve', label: 'RESERVE™', mg: 50 },
  { key: 'ascend', label: 'ASCEND™', mg: 100 },
];
export function DoseLadder({ activeTier, onSelect }) {
  const max = 100;
  return React.createElement('div', { style: { display: 'flex', gap: 12, alignItems: 'flex-end', fontFamily: 'var(--font-sans)' } },
    TIERS.map(t => {
      const h = 40 + (Math.log(t.mg) / Math.log(max)) * 100;
      const active = activeTier === t.key;
      return React.createElement('div', {
        key: t.key, onClick: () => onSelect && onSelect(t.key),
        style: { flex: 1, cursor: onSelect ? 'pointer' : 'default', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 },
      },
        React.createElement('div', {
          style: {
            width: '100%', height: h, background: `var(--tier-${t.key})`, borderRadius: 'var(--radius-sm) var(--radius-sm) 0 0',
            opacity: active || !activeTier ? 1 : 0.45, transition: 'opacity var(--duration-standard) var(--ease-standard)',
          },
        }),
        React.createElement('div', { style: { fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 12, letterSpacing: 'var(--tracking-label)', textTransform: 'uppercase', color: 'var(--ivory)' } }, t.label),
        React.createElement('div', { style: { fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-secondary-dark)' } }, `${t.mg}mg`));
    }));
}
