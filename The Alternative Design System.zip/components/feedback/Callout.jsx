import React from 'react';
export function Callout({ variant = 'info', title, children }) {
  const variants = {
    info: { border: 'var(--border-dark-strong)', accent: 'var(--gold-300)' },
    warning: { border: 'var(--warning-600)', accent: 'var(--warning-600)' },
  };
  const v = variants[variant] || variants.info;
  return React.createElement('div', {
    style: {
      display: 'flex', gap: 12, padding: 'var(--space-4)', background: 'var(--surface-card-dark)',
      border: `1px solid ${v.border}`, borderRadius: 'var(--radius-md)', fontFamily: 'var(--font-sans)',
    },
  },
    React.createElement('div', { style: { width: 3, borderRadius: 2, background: v.accent, flexShrink: 0 } }),
    React.createElement('div', {},
      title && React.createElement('div', { style: { fontWeight: 700, fontSize: 13, letterSpacing: 'var(--tracking-label)', textTransform: 'uppercase', color: v.accent, marginBottom: 4 } }, title),
      React.createElement('div', { style: { fontSize: 14, lineHeight: 'var(--lh-normal)', color: 'var(--text-secondary-dark)' } }, children)));
}
