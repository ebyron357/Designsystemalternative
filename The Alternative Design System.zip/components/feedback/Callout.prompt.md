Compliance/warning and informational banners. `warning` is reserved for legally required warnings and must never be visually suppressed or covered by design (source report §16: warnings must always stay legible).

```jsx
<Callout variant="warning" title="Age Restriction">For use only by adults 21 years of age or older.</Callout>
```
