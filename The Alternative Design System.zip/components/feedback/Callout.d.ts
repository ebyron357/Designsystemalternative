export interface CalloutProps {
  variant?: 'info' | 'warning';
  title?: string;
  children: React.ReactNode;
}
export function Callout(props: CalloutProps): JSX.Element;
