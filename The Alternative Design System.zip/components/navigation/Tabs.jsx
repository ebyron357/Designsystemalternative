import React from 'react';
export function Tabs({ tabs = [], active, onChange }) {
  return React.createElement('div', { style: { display: 'flex', gap: 'var(--space-6)', borderBottom: '1px solid var(--border-dark)', fontFamily: 'var(--font-sans)' } },
    tabs.map(t => React.createElement('button', {
      key: t, onClick: () => onChange && onChange(t),
      style: {
        background: 'none', border: 'none', padding: '10px 0', cursor: 'pointer',
        fontWeight: 700, fontSize: 13, letterSpacing: 'var(--tracking-label)', textTransform: 'uppercase',
        color: t === active ? 'var(--gold-300)' : 'var(--text-secondary-dark)',
        borderBottom: `2px solid ${t === active ? 'var(--gold-300)' : 'transparent'}`,
        transition: 'color var(--duration-standard) var(--ease-standard)',
      },
    }, t)));
}
