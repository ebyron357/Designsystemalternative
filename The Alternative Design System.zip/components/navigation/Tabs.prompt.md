Simple underline tab switcher — product-detail views (Overview / Ingredients / COA), wholesale portal sections.

```jsx
<Tabs tabs={['Overview', 'Ingredients', 'COA']} active={tab} onChange={setTab} />
```
