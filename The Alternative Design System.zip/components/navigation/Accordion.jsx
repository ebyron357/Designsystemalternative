import React from 'react';
export function Accordion({ items = [] }) {
  const [open, setOpen] = React.useState(null);
  return React.createElement('div', { style: { display: 'flex', flexDirection: 'column', fontFamily: 'var(--font-sans)' } },
    items.map((it, i) => React.createElement('div', { key: i, style: { borderBottom: '1px solid var(--border-dark)' } },
      React.createElement('button', {
        onClick: () => setOpen(open === i ? null : i),
        style: {
          width: '100%', textAlign: 'left', background: 'none', border: 'none', cursor: 'pointer',
          padding: '16px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          color: 'var(--ivory)', fontSize: 15, fontWeight: 600,
        },
      }, it.title, React.createElement('span', { style: { color: 'var(--gold-300)', fontFamily: 'var(--font-mono)' } }, open === i ? '−' : '+')),
      open === i && React.createElement('div', { style: { padding: '0 0 16px', color: 'var(--text-secondary-dark)', fontSize: 14, lineHeight: 'var(--lh-normal)' } }, it.content))));
}
