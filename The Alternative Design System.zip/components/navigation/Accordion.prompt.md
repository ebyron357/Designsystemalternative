Single-open disclosure list — FAQ page (dose, legality, shipping, responsible use per source report §15), product-facts breakdowns.

```jsx
<Accordion items={[{ title: 'How is dose measured?', content: 'Each can lists...' }]} />
```
