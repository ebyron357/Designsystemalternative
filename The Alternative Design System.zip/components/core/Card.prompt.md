Generic dark surface container — product cards, content cards, sell-sheet blocks. One step lighter than the page, hairline border, no drop shadow.

```jsx
<Card><Tag tier="session" mg={5} label="SESSION™" /></Card>
```
