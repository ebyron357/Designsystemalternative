export interface TagProps {
  tier?: 'session' | 'social' | 'reserve' | 'ascend';
  mg?: number;
  label?: string;
}
export function Tag(props: TagProps): JSX.Element;
