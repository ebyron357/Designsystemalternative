export interface BadgeProps {
  variant?: 'outline' | 'solid' | 'neutral';
  children: React.ReactNode;
}
export function Badge(props: BadgeProps): JSX.Element;
