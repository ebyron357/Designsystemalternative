Dose-tier chip — the one place tier color-coding is allowed to appear as a solid fill. Always pairs a tier name with its mg figure in mono.

```jsx
<Tag tier="social" mg={10} label="SOCIAL™" />
```
