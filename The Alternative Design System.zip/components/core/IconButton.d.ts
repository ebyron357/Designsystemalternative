export interface IconButtonProps {
  icon: React.ReactNode;
  ariaLabel: string;
  variant?: 'secondary' | 'ghost';
  size?: number;
  onClick?: () => void;
}
export function IconButton(props: IconButtonProps): JSX.Element;
