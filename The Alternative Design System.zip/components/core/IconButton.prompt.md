Square icon-only control (nav, cart, close, QR-scan trigger). Pass an icon element (e.g. a Lucide `<i data-lucide="...">` or inline SVG) as `icon`.

```jsx
<IconButton ariaLabel="Open cart" icon={<CartIcon />} />
```
