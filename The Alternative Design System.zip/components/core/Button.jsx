import React from 'react';
const SIZES = { sm: { padding: '8px 16px', fontSize: 13 }, md: { padding: '12px 22px', fontSize: 14 }, lg: { padding: '16px 30px', fontSize: 15 } };
export function Button({ variant = 'primary', size = 'md', disabled = false, children, onClick, style }) {
  const s = SIZES[size] || SIZES.md;
  const base = {
    fontFamily: 'var(--font-sans)', fontWeight: 700, letterSpacing: '0.04em', textTransform: 'uppercase',
    borderRadius: 'var(--radius-md)', cursor: disabled ? 'not-allowed' : 'pointer', border: '1px solid transparent',
    transition: 'background var(--duration-standard) var(--ease-standard), border-color var(--duration-standard) var(--ease-standard), opacity var(--duration-fast) var(--ease-standard)',
    whiteSpace: 'nowrap', flexShrink: 0, opacity: disabled ? 0.45 : 1, ...s, ...style,
  };
  const variants = {
    primary: { background: 'var(--accent)', color: 'var(--black)' },
    secondary: { background: 'transparent', color: 'var(--ivory)', borderColor: 'var(--border-dark-strong)' },
    ghost: { background: 'transparent', color: 'var(--gold-300)', borderColor: 'transparent' },
  };
  const [hover, setHover] = React.useState(false);
  const hoverStyles = {
    primary: { background: 'var(--accent-strong)' },
    secondary: { borderColor: 'var(--accent-strong)', color: 'var(--gold-300)' },
    ghost: { color: 'var(--accent-strong)' },
  };
  return React.createElement('button', {
    disabled, onClick,
    onMouseEnter: () => setHover(true), onMouseLeave: () => setHover(false),
    style: { ...base, ...variants[variant], ...(hover && !disabled ? hoverStyles[variant] : {}) },
  }, children);
}
