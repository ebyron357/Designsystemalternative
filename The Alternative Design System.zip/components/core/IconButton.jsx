import React from 'react';
export function IconButton({ icon, ariaLabel, variant = 'secondary', size = 36, onClick }) {
  const [hover, setHover] = React.useState(false);
  const variants = {
    secondary: { background: 'transparent', border: '1px solid var(--border-dark-strong)', color: 'var(--ivory)' },
    ghost: { background: 'transparent', border: '1px solid transparent', color: 'var(--gold-300)' },
  };
  return React.createElement('button', {
    'aria-label': ariaLabel, onClick,
    onMouseEnter: () => setHover(true), onMouseLeave: () => setHover(false),
    style: {
      width: size, height: size, borderRadius: 'var(--radius-md)', display: 'flex', alignItems: 'center', justifyContent: 'center',
      cursor: 'pointer', transition: 'border-color var(--duration-standard) var(--ease-standard), color var(--duration-standard) var(--ease-standard)',
      ...variants[variant], ...(hover ? { borderColor: 'var(--accent-strong)', color: 'var(--accent-strong)' } : {}),
    },
  }, icon);
}
