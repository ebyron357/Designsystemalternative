Small tracked-caps pill for credibility markers — "VETERAN-OWNED", "LAB-TESTED", "NC BUILT" — never for dose tiers (use `Tag` for that).

```jsx
<Badge variant="outline">Veteran-Owned</Badge>
```
