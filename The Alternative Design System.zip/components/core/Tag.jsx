import React from 'react';
const TIER_COLOR = { session: 'var(--tier-session)', social: 'var(--tier-social)', reserve: 'var(--tier-reserve)', ascend: 'var(--tier-ascend)' };
const TIER_INK = { session: 'var(--black)', social: 'var(--black)', reserve: 'var(--ivory)', ascend: 'var(--ivory)' };
export function Tag({ tier = 'session', mg, label }) {
  return React.createElement('span', {
    style: {
      display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 12px', borderRadius: 'var(--radius-sm)',
      background: TIER_COLOR[tier], color: TIER_INK[tier], fontFamily: 'var(--font-display)', fontWeight: 800,
      fontSize: 12, letterSpacing: 'var(--tracking-label)', textTransform: 'uppercase',
    },
  }, label || tier, mg != null && React.createElement('span', { style: { fontFamily: 'var(--font-mono)', fontWeight: 500 } }, `${mg}mg`));
}
