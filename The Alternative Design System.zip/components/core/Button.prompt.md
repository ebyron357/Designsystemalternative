Primary interactive control for CTAs and forms, in the brand's tracked-caps uppercase label style.

```jsx
<Button variant="primary" size="md" onClick={() => {}}>Shop Passion Fruit</Button>
```

Variants: `primary` (solid gold, for the single most important action per view), `secondary` (outlined, ivory text), `ghost` (text-only gold, for tertiary actions). Sizes: `sm`, `md`, `lg`. Use `disabled` for unavailable products/actions — never hide the control, per the brand's transparency value.
