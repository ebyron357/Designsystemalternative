import React from 'react';
export function Card({ children, onClick, style }) {
  const [hover, setHover] = React.useState(false);
  return React.createElement('div', {
    onClick, onMouseEnter: () => setHover(true), onMouseLeave: () => setHover(false),
    style: {
      background: 'var(--surface-card-dark)', border: `1px solid ${hover && onClick ? 'var(--border-dark-strong)' : 'var(--border-dark)'}`,
      borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-card-dark)', padding: 'var(--space-5)',
      cursor: onClick ? 'pointer' : 'default', transition: 'border-color var(--duration-standard) var(--ease-standard)',
      color: 'var(--ivory)', fontFamily: 'var(--font-sans)', ...style,
    },
  }, children);
}
