import React from 'react';
export function Badge({ variant = 'outline', children }) {
  const variants = {
    outline: { background: 'transparent', color: 'var(--gold-300)', border: '1px solid var(--border-dark-strong)' },
    solid: { background: 'var(--accent)', color: 'var(--black)', border: '1px solid transparent' },
    neutral: { background: 'var(--surface-raised-dark)', color: 'var(--text-secondary-dark)', border: '1px solid var(--border-dark)' },
  };
  return React.createElement('span', {
    style: {
      display: 'inline-flex', alignItems: 'center', padding: '5px 12px', borderRadius: 'var(--radius-pill)',
      fontFamily: 'var(--font-sans)', fontWeight: 700, fontSize: 11, letterSpacing: 'var(--tracking-label)', textTransform: 'uppercase',
      whiteSpace: 'nowrap', flexShrink: 0,
      ...variants[variant],
    },
  }, children);
}
