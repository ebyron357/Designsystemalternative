Used for age/consent confirmations (21+, responsible-use acknowledgment) and preference opt-ins.

```jsx
<Checkbox label="I am 21 years of age or older" checked={confirmed} onChange={setConfirmed} />
```
