import React from 'react';
export function Checkbox({ label, checked, onChange }) {
  return React.createElement('label', { style: { display: 'flex', alignItems: 'center', gap: 10, fontFamily: 'var(--font-sans)', fontSize: 14, color: 'var(--ivory)', cursor: 'pointer' } },
    React.createElement('span', {
      onClick: () => onChange && onChange(!checked),
      style: {
        width: 18, height: 18, borderRadius: 'var(--radius-sm)', border: `1px solid ${checked ? 'var(--accent)' : 'var(--border-dark-strong)'}`,
        background: checked ? 'var(--accent)' : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center',
        transition: 'background var(--duration-fast) var(--ease-standard)', flexShrink: 0,
      },
    }, checked && React.createElement('span', { style: { width: 8, height: 8, background: 'var(--black)', borderRadius: 1 } })),
    label);
}
