Dropdown for flavor/tier/state selection (e.g. age-gate state selector, flavor picker).

```jsx
<Select label="Flavor" options={['Passion Fruit', 'Mango', 'Grape']} value={flavor} onChange={setFlavor} />
```
