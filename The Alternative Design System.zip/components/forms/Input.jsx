import React from 'react';
export function Input({ label, placeholder, value, onChange, type = 'text' }) {
  const [focus, setFocus] = React.useState(false);
  return React.createElement('label', { style: { display: 'flex', flexDirection: 'column', gap: 6, fontFamily: 'var(--font-sans)' } },
    label && React.createElement('span', { style: { fontSize: 12, fontWeight: 700, letterSpacing: 'var(--tracking-label)', textTransform: 'uppercase', color: 'var(--text-secondary-dark)' } }, label),
    React.createElement('input', {
      type, placeholder, value, onChange: e => onChange && onChange(e.target.value),
      onFocus: () => setFocus(true), onBlur: () => setFocus(false),
      style: {
        background: 'var(--surface-card-dark)', color: 'var(--ivory)', border: `1px solid ${focus ? 'var(--accent-strong)' : 'var(--border-dark-strong)'}`,
        borderRadius: 'var(--radius-md)', padding: '12px 14px', fontSize: 14, fontFamily: 'var(--font-sans)', outline: 'none',
        boxShadow: focus ? 'var(--shadow-gold-glow)' : 'none', transition: 'border-color var(--duration-standard) var(--ease-standard)',
      },
    }));
}
