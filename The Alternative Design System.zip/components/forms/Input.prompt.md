Text field for email capture, order forms, wholesale inquiries. Focus state uses the gold glow token, never a blue browser-default ring.

```jsx
<Input label="Email" placeholder="you@domain.com" value={email} onChange={setEmail} />
```
